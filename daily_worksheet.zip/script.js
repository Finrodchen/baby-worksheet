// 全局變數
let currentChild = 'child1';
let currentDate = new Date();
let children = {
    child1: { name: '宥融', data: {} },
    child2: { name: '玥熙', data: {} }
};

// 登入相關變數
let isLoggedIn = false;
const VALID_USERNAME = 's02260441';
const VALID_PASSWORD = '02260441';

// 登入相關函數
function checkLogin() {
    const savedLoginStatus = localStorage.getItem('isLoggedIn');
    if (savedLoginStatus === 'true') {
        isLoggedIn = true;
        showMainApp();
    } else {
        showLoginForm();
    }
}

function showLoginForm() {
    document.getElementById('loginContainer').style.display = 'flex';
    document.getElementById('mainApp').style.display = 'none';
}

function showMainApp() {
    document.getElementById('loginContainer').style.display = 'none';
    document.getElementById('mainApp').style.display = 'block';
}

function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('loginError');
    
    if (username === VALID_USERNAME && password === VALID_PASSWORD) {
        isLoggedIn = true;
        localStorage.setItem('isLoggedIn', 'true');
        showMainApp();
        initializeApp();
        setupEventListeners();
        loadData();
        updateCurrentDate();
        showTab('schedule');
        errorDiv.style.display = 'none';
    } else {
        errorDiv.textContent = '❌ 帳號或密碼錯誤，請重新輸入';
        errorDiv.style.display = 'block';
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
    }
}

function handleLogout() {
    if (confirm('確定要登出嗎？')) {
        isLoggedIn = false;
        localStorage.removeItem('isLoggedIn');
        showLoginForm();
        // 清空表單
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
    }
}

// 預設作息表
const defaultSchedule = [
    { time: '06:30-07:00', activity: '起床、梳洗、早餐', note: '你每天都能準時起床，真棒！' },
    { time: '07:00-07:30', activity: '整理書包、準備上學', note: '自己準備，越來越獨立了！' },
    { time: '07:30-16:00', activity: '上學', note: '今天在學校表現很棒！' },
    { time: '16:00-16:30', activity: '回家、休息、點心', note: '辛苦一天了，休息一下！' },
    { time: '16:30-17:30', activity: '完成作業、複習', note: '努力學習，進步真快！' },
    { time: '17:30-18:00', activity: '運動或戶外活動', note: '運動讓你更健康有活力！' },
    { time: '18:00-19:00', activity: '晚餐、家人互動', note: '和家人一起吃飯最幸福！' },
    { time: '19:00-19:30', activity: '閱讀或才藝練習', note: '你越來越愛閱讀了！' },
    { time: '19:30-20:00', activity: '洗澡、準備睡覺', note: '你會自己照顧身體，真棒！' },
    { time: '20:00-20:30', activity: '親子對話、分享', note: '今天有什麼值得驕傲的事？' },
    { time: '20:30', activity: '上床睡覺', note: '晚安，明天又是美好的一天！' }
];

// 預設積分項目
const defaultPointsTasks = [
    { name: '準時起床', points: 1 },
    { name: '完成功課', points: 2 },
    { name: '幫忙家事', points: 1 },
    { name: '閱讀30分鐘', points: 1 },
    { name: '運動30分鐘', points: 1 },
    { name: '分享心得', points: 1 }
];

// 預設獎勵項目
const defaultRewards = [
    { name: '🎨 貼紙一張', cost: 10 },
    { name: '📝 小文具', cost: 15 },
    { name: '🎁 小禮物', cost: 30 },
    { name: '🎮 遊戲時間30分鐘', cost: 25 },
    { name: '🍦 冰淇淋', cost: 20 },
    { name: '🎪 親子共遊', cost: 50 }
];

// 初始化應用
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadData();
    updateCurrentDate();
    showTab('schedule');
});

// 初始化應用
function initializeApp() {
    // 初始化每個孩子的數據
    Object.keys(children).forEach(childId => {
        if (!children[childId].data.schedule) {
            children[childId].data.schedule = [...defaultSchedule];
        }
        if (!children[childId].data.pointsTasks) {
            children[childId].data.pointsTasks = [...defaultPointsTasks];
        }
        if (!children[childId].data.rewards) {
            children[childId].data.rewards = [...defaultRewards];
        }
        if (!children[childId].data.dailyRecords) {
            children[childId].data.dailyRecords = {};
        }
        if (!children[childId].data.totalPoints) {
            children[childId].data.totalPoints = 0;
        }
    });
}

// 設置事件監聽器
function setupEventListeners() {
    // 登入表單事件
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // 登出按鈕事件
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // 標籤切換
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.getAttribute('data-tab');
            showTab(tabName);
        });
    });

    // 孩子選擇
    document.getElementById('childSelect').addEventListener('change', (e) => {
        currentChild = e.target.value;
        refreshCurrentView();
    });

    // 新增孩子
    document.getElementById('addChildBtn').addEventListener('click', addNewChild);
    
    // 刪除孩子
    document.getElementById('deleteChildBtn').addEventListener('click', deleteChild);

    // 日期導航
    document.getElementById('prevDay').addEventListener('click', () => {
        currentDate.setDate(currentDate.getDate() - 1);
        updateCurrentDate();
        refreshCurrentView();
    });

    document.getElementById('nextDay').addEventListener('click', () => {
        currentDate.setDate(currentDate.getDate() + 1);
        updateCurrentDate();
        refreshCurrentView();
    });

    // 編輯按鈕
    document.getElementById('editScheduleBtn').addEventListener('click', () => {
        showTab('settings');
    });

    // 設定頁面按鈕
    document.getElementById('addScheduleItem').addEventListener('click', addScheduleItem);
    document.getElementById('saveSchedule').addEventListener('click', saveSchedule);
    document.getElementById('addPointsItem').addEventListener('click', addPointsItem);
    document.getElementById('savePoints').addEventListener('click', savePoints);
    document.getElementById('addRewardItem').addEventListener('click', addRewardItem);
    document.getElementById('saveRewards').addEventListener('click', saveRewards);
    
    // 數據管理按鈕
    document.getElementById('exportDataBtn').addEventListener('click', exportData);
    document.getElementById('importDataBtn').addEventListener('click', () => {
        document.getElementById('importFileInput').click();
    });
    document.getElementById('importFileInput').addEventListener('change', importData);

    // 模態框
    document.querySelector('.close').addEventListener('click', closeModal);
    window.addEventListener('click', (e) => {
        if (e.target === document.getElementById('modal')) {
            closeModal();
        }
    });
}

// 顯示標籤
function showTab(tabName) {
    // 隱藏所有標籤內容
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // 移除所有標籤按鈕的活動狀態
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // 顯示選中的標籤
    document.getElementById(tabName).classList.add('active');
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // 根據標籤更新內容
    switch(tabName) {
        case 'schedule':
            displaySchedule();
            break;
        case 'points':
            displayPoints();
            break;
        case 'history':
            displayHistory();
            break;
        case 'settings':
            displaySettings();
            break;
    }
}

// 更新當前日期顯示
function updateCurrentDate() {
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        weekday: 'long'
    };
    document.getElementById('currentDate').textContent = 
        currentDate.toLocaleDateString('zh-TW', options);
}

// 顯示作息表
function displaySchedule() {
    const scheduleList = document.getElementById('scheduleList');
    const schedule = children[currentChild].data.schedule;
    const dateKey = formatDate(currentDate);
    const childData = children[currentChild].data;
    const dailyRecord = childData.dailyRecords[dateKey] || {};
    
    scheduleList.innerHTML = '';
    
    schedule.forEach((item, index) => {
        const scheduleItem = document.createElement('div');
        scheduleItem.className = 'schedule-item';
        const isCompleted = dailyRecord.schedule && dailyRecord.schedule[index];
        
        if (isCompleted) {
            scheduleItem.classList.add('schedule-completed');
        }
        
        scheduleItem.innerHTML = `
            <div class="schedule-time">${item.time}</div>
            <div class="schedule-activity">${item.activity}</div>
            <input type="checkbox" class="schedule-checkbox" ${isCompleted ? 'checked' : ''} 
                   onchange="toggleScheduleItem(${index})">
        `;
        scheduleList.appendChild(scheduleItem);
    });
}

// 顯示積分頁面
function displayPoints() {
    const dateKey = formatDate(currentDate);
    const childData = children[currentChild].data;
    const dailyRecord = childData.dailyRecords[dateKey] || {};
    
    // 更新總積分和週積分
    document.getElementById('totalPoints').textContent = childData.totalPoints || 0;
    document.getElementById('weeklyPoints').textContent = calculateWeeklyPoints();
    
    // 顯示今日任務
    const tasksContainer = document.getElementById('pointsTasksList');
    tasksContainer.innerHTML = '';
    
    childData.pointsTasks.forEach((task, index) => {
        const taskElement = document.createElement('div');
        taskElement.className = 'points-task';
        const isCompleted = dailyRecord.tasks && dailyRecord.tasks[index];
        
        if (isCompleted) {
            taskElement.classList.add('task-completed');
        }
        
        taskElement.innerHTML = `
            <div class="task-info">
                <div class="task-name">${task.name}</div>
                <div class="task-points">+${task.points}分</div>
            </div>
            <input type="checkbox" class="task-checkbox" ${isCompleted ? 'checked' : ''} 
                   onchange="toggleTask(${index})">
        `;
        
        tasksContainer.appendChild(taskElement);
    });
    
    // 顯示獎勵項目
    displayRewards();
}

// 顯示獎勵項目
function displayRewards() {
    const rewardsContainer = document.getElementById('rewardsList');
    const rewards = children[currentChild].data.rewards;
    const totalPoints = children[currentChild].data.totalPoints || 0;
    
    rewardsContainer.innerHTML = '';
    
    rewards.forEach((reward, index) => {
        const rewardElement = document.createElement('div');
        rewardElement.className = 'reward-item';
        const canAfford = totalPoints >= reward.cost;
        
        rewardElement.innerHTML = `
            <div class="reward-name">${reward.name}</div>
            <div class="reward-cost">需要 ${reward.cost} 積分</div>
            <button class="reward-btn" ${!canAfford ? 'disabled' : ''} 
                    onclick="redeemReward(${index})">
                ${canAfford ? '兌換' : '積分不足'}
            </button>
        `;
        
        rewardsContainer.appendChild(rewardElement);
    });
}

// 切換作息項目完成狀態
function toggleScheduleItem(scheduleIndex) {
    const dateKey = formatDate(currentDate);
    const childData = children[currentChild].data;
    
    if (!childData.dailyRecords[dateKey]) {
        childData.dailyRecords[dateKey] = { schedule: {} };
    }
    
    if (!childData.dailyRecords[dateKey].schedule) {
        childData.dailyRecords[dateKey].schedule = {};
    }
    
    const wasCompleted = childData.dailyRecords[dateKey].schedule[scheduleIndex];
    childData.dailyRecords[dateKey].schedule[scheduleIndex] = !wasCompleted;
    
    // 如果是勾選完成，顯示鼓勵話語
    if (!wasCompleted) {
        const scheduleItem = children[currentChild].data.schedule[scheduleIndex];
        const encouragement = scheduleItem?.note;
        showEncouragementPopup(encouragement);
    }
    
    saveData();
    displaySchedule();
}

// 切換任務完成狀態
function toggleTask(taskIndex) {
    const dateKey = formatDate(currentDate);
    const childData = children[currentChild].data;
    
    if (!childData.dailyRecords[dateKey]) {
        childData.dailyRecords[dateKey] = { tasks: {} };
    }
    
    if (!childData.dailyRecords[dateKey].tasks) {
        childData.dailyRecords[dateKey].tasks = {};
    }
    
    const wasCompleted = childData.dailyRecords[dateKey].tasks[taskIndex];
    childData.dailyRecords[dateKey].tasks[taskIndex] = !wasCompleted;
    
    // 更新總積分
    const taskPoints = childData.pointsTasks[taskIndex].points;
    if (!wasCompleted) {
        childData.totalPoints = (childData.totalPoints || 0) + taskPoints;
    } else {
        childData.totalPoints = (childData.totalPoints || 0) - taskPoints;
    }
    
    saveData();
    displayPoints();
}

// 兌換獎勵
function redeemReward(rewardIndex) {
    const childData = children[currentChild].data;
    const reward = childData.rewards[rewardIndex];
    const totalPoints = childData.totalPoints || 0;
    
    if (totalPoints >= reward.cost) {
        if (confirm(`確定要兌換「${reward.name}」嗎？將扣除 ${reward.cost} 積分。`)) {
            childData.totalPoints -= reward.cost;
            
            // 記錄兌換歷史
            const dateKey = formatDate(new Date());
            if (!childData.dailyRecords[dateKey]) {
                childData.dailyRecords[dateKey] = {};
            }
            if (!childData.dailyRecords[dateKey].rewards) {
                childData.dailyRecords[dateKey].rewards = [];
            }
            childData.dailyRecords[dateKey].rewards.push({
                name: reward.name,
                cost: reward.cost,
                time: new Date().toLocaleTimeString('zh-TW')
            });
            
            saveData();
            displayPoints();
            alert(`🎉 恭喜！成功兌換「${reward.name}」！`);
        }
    }
}

// 計算週積分
function calculateWeeklyPoints() {
    const childData = children[currentChild].data;
    const today = new Date();
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    
    let weeklyPoints = 0;
    
    for (let i = 0; i < 7; i++) {
        const date = new Date(weekStart);
        date.setDate(weekStart.getDate() + i);
        const dateKey = formatDate(date);
        
        const dailyRecord = childData.dailyRecords[dateKey];
        if (dailyRecord && dailyRecord.tasks) {
            Object.keys(dailyRecord.tasks).forEach(taskIndex => {
                if (dailyRecord.tasks[taskIndex]) {
                    weeklyPoints += childData.pointsTasks[taskIndex]?.points || 0;
                }
            });
        }
    }
    
    return weeklyPoints;
}

// 顯示歷史記錄
function displayHistory() {
    const historyContent = document.getElementById('historyContent');
    const childData = children[currentChild].data;
    
    // 填充月份選擇器
    const monthSelect = document.getElementById('historyMonth');
    monthSelect.innerHTML = '<option value="">選擇月份</option>';
    
    const months = new Set();
    Object.keys(childData.dailyRecords).forEach(dateKey => {
        const date = new Date(dateKey);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        months.add(monthKey);
    });
    
    Array.from(months).sort().reverse().forEach(monthKey => {
        const option = document.createElement('option');
        option.value = monthKey;
        option.textContent = monthKey;
        monthSelect.appendChild(option);
    });
    
    // 顯示所有記錄
    displayHistoryRecords();
    
    // 設置篩選事件
    monthSelect.addEventListener('change', displayHistoryRecords);
    document.getElementById('historyType').addEventListener('change', displayHistoryRecords);
}

// 顯示歷史記錄內容
function displayHistoryRecords() {
    const historyContent = document.getElementById('historyContent');
    const childData = children[currentChild].data;
    const selectedMonth = document.getElementById('historyMonth').value;
    const selectedType = document.getElementById('historyType').value;
    
    historyContent.innerHTML = '';
    
    const sortedDates = Object.keys(childData.dailyRecords).sort().reverse();
    
    sortedDates.forEach(dateKey => {
        const date = new Date(dateKey);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        
        if (selectedMonth && monthKey !== selectedMonth) return;
        
        const record = childData.dailyRecords[dateKey];
        const recordElement = document.createElement('div');
        recordElement.style.marginBottom = '20px';
        recordElement.style.padding = '15px';
        recordElement.style.background = '#fff';
        recordElement.style.borderRadius = '10px';
        recordElement.style.border = '2px solid #DDA0DD';
        
        let content = `<h4>${date.toLocaleDateString('zh-TW', { 
            year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' 
        })}</h4>`;
        
        if ((selectedType === 'all' || selectedType === 'points') && record.tasks) {
            content += '<h5>📊 完成任務：</h5><ul>';
            Object.keys(record.tasks).forEach(taskIndex => {
                if (record.tasks[taskIndex]) {
                    const task = childData.pointsTasks[taskIndex];
                    if (task) {
                        content += `<li>${task.name} (+${task.points}分)</li>`;
                    }
                }
            });
            content += '</ul>';
        }
        
        if ((selectedType === 'all' || selectedType === 'points') && record.rewards) {
            content += '<h5>🎁 兌換獎勵：</h5><ul>';
            record.rewards.forEach(reward => {
                content += `<li>${reward.name} (-${reward.cost}分) ${reward.time}</li>`;
            });
            content += '</ul>';
        }
        
        recordElement.innerHTML = content;
        historyContent.appendChild(recordElement);
    });
    
    if (historyContent.children.length === 0) {
        historyContent.innerHTML = '<p style="text-align: center; color: #666;">暫無記錄</p>';
    }
}

// 顯示設定頁面
function displaySettings() {
    displayScheduleEditor();
    displayPointsEditor();
    displayRewardsEditor();
}

// 顯示作息表編輯器
function displayScheduleEditor() {
    const container = document.getElementById('scheduleEditorList');
    const schedule = children[currentChild].data.schedule;
    
    container.innerHTML = '';
    
    schedule.forEach((item, index) => {
        const editorItem = document.createElement('div');
        editorItem.className = 'editor-item';
        editorItem.innerHTML = `
            <input type="text" value="${item.time}" placeholder="時間" data-field="time" data-index="${index}">
            <input type="text" value="${item.activity}" placeholder="活動內容" data-field="activity" data-index="${index}">
            <textarea placeholder="鼓勵話語" data-field="encouragement" data-index="${index}">${item.encouragement}</textarea>
            <button class="delete-btn" onclick="deleteScheduleItem(${index})">🗑️</button>
        `;
        container.appendChild(editorItem);
    });
}

// 顯示積分項目編輯器
function displayPointsEditor() {
    const container = document.getElementById('pointsEditorList');
    const pointsTasks = children[currentChild].data.pointsTasks;
    
    container.innerHTML = '';
    
    pointsTasks.forEach((task, index) => {
        const editorItem = document.createElement('div');
        editorItem.className = 'editor-item';
        editorItem.innerHTML = `
            <input type="text" value="${task.name}" placeholder="任務名稱" data-field="name" data-index="${index}">
            <input type="number" value="${task.points}" placeholder="積分" min="1" data-field="points" data-index="${index}">
            <button class="delete-btn" onclick="deletePointsItem(${index})">🗑️</button>
        `;
        container.appendChild(editorItem);
    });
}

// 顯示獎勵項目編輯器
function displayRewardsEditor() {
    const container = document.getElementById('rewardsEditorList');
    const rewards = children[currentChild].data.rewards;
    
    container.innerHTML = '';
    
    rewards.forEach((reward, index) => {
        const editorItem = document.createElement('div');
        editorItem.className = 'editor-item';
        editorItem.innerHTML = `
            <input type="text" value="${reward.name}" placeholder="獎勵名稱" data-field="name" data-index="${index}">
            <input type="number" value="${reward.cost}" placeholder="所需積分" min="1" data-field="cost" data-index="${index}">
            <button class="delete-btn" onclick="deleteRewardItem(${index})">🗑️</button>
        `;
        container.appendChild(editorItem);
    });
}

// 新增作息項目
function addScheduleItem() {
    children[currentChild].data.schedule.push({
        time: '',
        activity: '',
        note: ''
    });
    displayScheduleEditor();
}

// 新增積分項目
function addPointsItem() {
    children[currentChild].data.pointsTasks.push({
        name: '',
        points: 1
    });
    displayPointsEditor();
}

// 新增獎勵項目
function addRewardItem() {
    children[currentChild].data.rewards.push({
        name: '',
        cost: 10
    });
    displayRewardsEditor();
}

// 刪除作息項目
function deleteScheduleItem(index) {
    if (confirm('確定要刪除這個作息項目嗎？')) {
        children[currentChild].data.schedule.splice(index, 1);
        displayScheduleEditor();
    }
}

// 刪除積分項目
function deletePointsItem(index) {
    if (confirm('確定要刪除這個積分項目嗎？')) {
        children[currentChild].data.pointsTasks.splice(index, 1);
        displayPointsEditor();
    }
}

// 刪除獎勵項目
function deleteRewardItem(index) {
    if (confirm('確定要刪除這個獎勵項目嗎？')) {
        children[currentChild].data.rewards.splice(index, 1);
        displayRewardsEditor();
    }
}

// 儲存作息表
function saveSchedule() {
    const inputs = document.querySelectorAll('#modalContent input, #modalContent textarea');
    const schedule = children[currentChild].data.schedule;
    
    inputs.forEach(input => {
        const field = input.dataset.field;
        const index = parseInt(input.dataset.index);
        
        if (schedule[index] && field) {
            schedule[index][field] = input.value;
        }
    });
    
    saveData();
    displaySchedule();
    closeModal();
}

// 儲存積分項目
function savePoints() {
    const container = document.getElementById('pointsEditorList');
    const inputs = container.querySelectorAll('input');
    
    inputs.forEach(input => {
        const index = parseInt(input.dataset.index);
        const field = input.dataset.field;
        let value = input.value;
        
        if (field === 'points') {
            value = parseInt(value) || 1;
        }
        
        children[currentChild].data.pointsTasks[index][field] = value;
    });
    
    saveData();
    alert('積分項目已儲存！');
    displayPoints();
}

// 儲存獎勵項目
function saveRewards() {
    const container = document.getElementById('rewardsEditorList');
    const inputs = container.querySelectorAll('input');
    
    inputs.forEach(input => {
        const index = parseInt(input.dataset.index);
        const field = input.dataset.field;
        let value = input.value;
        
        if (field === 'cost') {
            value = parseInt(value) || 10;
        }
        
        children[currentChild].data.rewards[index][field] = value;
    });
    
    saveData();
    alert('獎勵項目已儲存！');
    displayRewards();
}

// 新增孩子
function addNewChild() {
    const name = prompt('請輸入新孩子的名字：');
    if (name && name.trim()) {
        const childId = 'child' + Date.now();
        children[childId] = {
            name: name.trim(),
            data: {
                schedule: [...defaultSchedule],
                pointsTasks: [...defaultPointsTasks],
                rewards: [...defaultRewards],
                dailyRecords: {},
                totalPoints: 0
            }
        };
        
        // 更新選擇器
        const select = document.getElementById('childSelect');
        const option = document.createElement('option');
        option.value = childId;
        option.textContent = name.trim();
        select.appendChild(option);
        
        // 切換到新孩子
        currentChild = childId;
        select.value = childId;
        
        saveData();
        refreshCurrentView();
    }
}

function deleteChild() {
    const childrenKeys = Object.keys(children);
    
    // 檢查是否至少有兩個孩子（不能刪除到只剩一個）
    if (childrenKeys.length <= 1) {
        alert('至少需要保留一個小朋友！');
        return;
    }
    
    const currentChildName = children[currentChild].name;
    const confirmMessage = `確定要刪除「${currentChildName}」的所有數據嗎？\n\n⚠️ 此操作無法復原，將會永久刪除：\n• 所有作息記錄\n• 積分記錄\n• 獎勵兌換記錄\n• 個人設定`;
    
    if (confirm(confirmMessage)) {
        // 刪除當前孩子的數據
        delete children[currentChild];
        
        // 更新選擇器
        const select = document.getElementById('childSelect');
        select.innerHTML = '';
        
        Object.keys(children).forEach(childId => {
            const option = document.createElement('option');
            option.value = childId;
            option.textContent = children[childId].name;
            select.appendChild(option);
        });
        
        // 切換到第一個可用的孩子
        const remainingChildren = Object.keys(children);
        if (remainingChildren.length > 0) {
            currentChild = remainingChildren[0];
            select.value = currentChild;
        }
        
        saveData();
        refreshCurrentView();
        
        alert(`已成功刪除「${currentChildName}」的所有數據。`);
    }
}

// 刷新當前視圖
function refreshCurrentView() {
    const activeTab = document.querySelector('.tab-btn.active').getAttribute('data-tab');
    showTab(activeTab);
}

// 格式化日期
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

// 顯示鼓勵話語彈窗
function showEncouragementPopup(message) {
    alert(`🎉 太棒了！\n\n${message}`);
}

// 顯示模態框
function showModal(content) {
    document.getElementById('modalBody').innerHTML = content;
    document.getElementById('modal').style.display = 'block';
}

// 關閉模態框
function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

// 儲存數據到本地存儲
function saveData() {
    localStorage.setItem('childrenData', JSON.stringify(children));
}

// 從本地存儲載入數據
function loadData() {
    const savedData = localStorage.getItem('childrenData');
    if (savedData) {
        try {
            const parsedData = JSON.parse(savedData);
            children = { ...children, ...parsedData };
            
            // 更新孩子選擇器
            const select = document.getElementById('childSelect');
            select.innerHTML = '';
            
            Object.keys(children).forEach(childId => {
                const option = document.createElement('option');
                option.value = childId;
                option.textContent = children[childId].name;
                select.appendChild(option);
            });
            
            // 設置當前選中的孩子
            if (Object.keys(children).length > 0) {
                currentChild = Object.keys(children)[0];
                select.value = currentChild;
            }
        } catch (error) {
            console.error('載入數據時發生錯誤:', error);
        }
    }
}

// 匯出數據
function exportData() {
    const dataStr = JSON.stringify(children, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'children_data.json';
    link.click();
    URL.revokeObjectURL(url);
}

// 匯入數據
function importData(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const importedData = JSON.parse(e.target.result);
                children = importedData;
                saveData();
                loadData();
                refreshCurrentView();
                alert('數據匯入成功！');
            } catch (error) {
                alert('匯入失敗：文件格式不正確');
            }
        };
        reader.readAsText(file);
    }
}

// 應用程式啟動
document.addEventListener('DOMContentLoaded', function() {
    // 首先設置登入相關的事件監聽器
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // 檢查登入狀態
    checkLogin();
    
    // 如果已經登入，初始化應用程式
    if (isLoggedIn) {
        initializeApp();
        setupEventListeners();
        loadData();
        updateCurrentDate();
        showTab('schedule');
    }
});